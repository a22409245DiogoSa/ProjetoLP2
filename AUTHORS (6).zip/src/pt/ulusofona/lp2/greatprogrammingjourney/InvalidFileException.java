package pt.ulusofona.lp2.greatprogrammingjourney;

public class InvalidFileException extends Exception {

    public InvalidFileException() {
        super();
    }

    public InvalidFileException(String msg) {
        super(msg);
    }
}
