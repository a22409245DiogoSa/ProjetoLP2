package pt.ulusofona.lp2.greatprogrammingjourney;

public enum EstadoJogo {
    EM_ANDAMENTO,
    TERMINADO
}
